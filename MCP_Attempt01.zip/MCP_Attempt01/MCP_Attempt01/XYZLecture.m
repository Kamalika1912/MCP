//
//  XYZLecture.m
//  MCP_Attempt01
//
//  Created by Devashish Jasani on 09/06/14.
//  Copyright (c) 2014 Devashish Jasani. All rights reserved.
//

#import "XYZLecture.h"

@implementation XYZLecture

-(NSMutableArray *)getFlashcardListByLecture:(NSInteger)subjectID {
    
    return nil;
    
}

@end
