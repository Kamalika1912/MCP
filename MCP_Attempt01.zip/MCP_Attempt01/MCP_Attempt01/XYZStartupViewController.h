//
//  XYZStartupViewController.h
//  MCP_Attempt01
//
//  Created by Devashish Jasani on 10/06/14.
//  Copyright (c) 2014 Devashish Jasani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZStartupViewController : UIViewController

@property IBOutlet UILabel *username;
@property IBOutlet UILabel *coins;
@property IBOutlet UIView *briefProfileOverview;





@end
