//
//  XYZProfile.m
//  MCP_Attempt01
//
//  Created by Devashish Jasani on 09/06/14.
//  Copyright (c) 2014 Devashish Jasani. All rights reserved.
//

#import "XYZProfile.h"

@implementation XYZProfile

-(XYZProfile *)init
{
    
    return nil;
}

-(void)getListOfSubjects
{
    
    
    
}

@end
